package com.mobdeve.s12.wu.waynes.exercise2

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class PostAdapter(private val postList: ArrayList<Post>) :
    RecyclerView.Adapter<PostAdapter.PostViewHolder>() {

    private var hideLikesEnabled = false // Default value

    class PostViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val profilePhoto: ImageView = itemView.findViewById(R.id.profilephoto)
        val username: TextView = itemView.findViewById(R.id.username)
        val postLocation: TextView = itemView.findViewById(R.id.postlocation)
        val postImage: ImageView = itemView.findViewById(R.id.postimage)
        val username2: TextView = itemView.findViewById(R.id.username2)
        val desc: TextView = itemView.findViewById(R.id.desc)
        val date: TextView = itemView.findViewById(R.id.date)
        val likeButton: ImageView = itemView.findViewById(R.id.btn_like) // Example ID for like button
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PostViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.post, parent, false)
        return PostViewHolder(view)
    }

    override fun onBindViewHolder(holder: PostViewHolder, position: Int) {
        val post = postList[position]
        holder.profilePhoto.setImageResource(post.userImageId)
        holder.username.text = post.username
        holder.postLocation.text = post.location
        holder.postImage.setImageResource(post.imageId)
        holder.username2.text = post.username
        holder.desc.text = post.caption
        holder.date.text = post.datePosted

        // Set initial like button state
        if (post.liked) {
            holder.likeButton.setImageResource(R.drawable.filled_heart)
        } else {
            holder.likeButton.setImageResource(R.drawable.unfilled_heart)
        }

        // Set click listener for like button
        holder.likeButton.setOnClickListener {
            // Toggle like state
            post.liked = !post.liked
            if (post.liked) {
                holder.likeButton.setImageResource(R.drawable.filled_heart)
            } else {
                holder.likeButton.setImageResource(R.drawable.unfilled_heart)
            }

            // Notify adapter that data set has changed
            notifyDataSetChanged()
        }

        // Set visibility of like button based on hideLikesEnabled
        if (hideLikesEnabled) {
            holder.likeButton.visibility = View.GONE
        } else {
            holder.likeButton.visibility = View.VISIBLE
        }
    }

    override fun getItemCount(): Int {
        return postList.size
    }

    // Function to update hideLikesEnabled and notify adapter of changes
    fun setHideLikesEnabled(hideLikesEnabled: Boolean) {
        this.hideLikesEnabled = hideLikesEnabled
        notifyDataSetChanged() // Notify RecyclerView that data set has changed
    }
}
