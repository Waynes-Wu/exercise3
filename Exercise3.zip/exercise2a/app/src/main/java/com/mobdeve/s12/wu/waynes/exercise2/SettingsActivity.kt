package com.mobdeve.s12.wu.waynes.exercise2

import android.content.SharedPreferences
import android.os.Bundle
import android.widget.Switch
import androidx.appcompat.app.AppCompatActivity
import com.mobdeve.s12.wu.waynes.exercise2.R

class SettingsActivity : AppCompatActivity() {

    private lateinit var sharedPrefs: SharedPreferences
    private lateinit var switchGridView: Switch
    private lateinit var switchHideLikes: Switch

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.settings_activity)

        // Initialize SharedPreferences
        sharedPrefs = getSharedPreferences("MyPrefs", MODE_PRIVATE)

        // Retrieve switch views from layout
        switchGridView = findViewById(R.id.switchGridView)
        switchHideLikes = findViewById(R.id.switchHideLikes)

        // Retrieve and apply previously saved switch states
        val switchGridViewEnabled = sharedPrefs.getBoolean("gridViewEnabled", false)
        val switchHideLikesEnabled = sharedPrefs.getBoolean("hideLikesEnabled", false)

        // Set initial switch states
        switchGridView.isChecked = switchGridViewEnabled
        switchHideLikes.isChecked = switchHideLikesEnabled

        // Handle switch state changes
        switchGridView.setOnCheckedChangeListener { _, isChecked ->
            // Save the state in SharedPreferences
            sharedPrefs.edit().putBoolean("gridViewEnabled", isChecked).apply()

            // Apply changes throughout the app (e.g., update RecyclerView layout)
            // Implement the logic to update the RecyclerView's layout based on isChecked
        }

        switchHideLikes.setOnCheckedChangeListener { _, isChecked ->
            // Save the state in SharedPreferences
            sharedPrefs.edit().putBoolean("hideLikesEnabled", isChecked).apply()

            // Apply changes throughout the app (e.g., hide/show like button)
            // Implement the logic to show/hide the like button based on isChecked
        }
    }
}
